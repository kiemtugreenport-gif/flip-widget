package com.example.flipwidget

import android.content.Context

/** Thành phố do người dùng chọn trong màn hình cài đặt (mặc định: Hà Nội). */
object Config {
    const val WEATHER_REFRESH_MS = 30 * 60 * 1000L
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", 0)
    fun city(ctx: Context): String = p(ctx).getString("city", "Hà Nội") ?: "Hà Nội"
    fun lat(ctx: Context): Double = (p(ctx).getString("lat", "21.0285") ?: "21.0285").toDouble()
    fun lon(ctx: Context): Double = (p(ctx).getString("lon", "105.8542") ?: "105.8542").toDouble()
    fun style(ctx: Context): Int = p(ctx).getInt("style", 0)
    fun saveStyle(ctx: Context, i: Int) { p(ctx).edit().putInt("style", i).apply() }
    fun save(ctx: Context, city: String, lat: Double, lon: Double) {
        p(ctx).edit().putString("city", city).putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
        ctx.getSharedPreferences("weather", 0).edit().clear().apply() // bỏ thời tiết của thành phố cũ
    }
}
