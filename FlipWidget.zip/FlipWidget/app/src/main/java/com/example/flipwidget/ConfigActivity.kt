package com.example.flipwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Màn hình chọn thành phố: mở khi thêm widget, khi chạm giữ widget > Cài đặt, hoặc mở ứng dụng. */
class ConfigActivity : Activity() {
    private class Place(val name: String, val label: String, val lat: Double, val lon: Double)
    private val places = mutableListOf<Place>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(px(20), px(48), px(20), px(20)) }
        root.addView(TextView(this).apply { text = "Chọn thành phố"; textSize = 22f })
        root.addView(TextView(this).apply { text = "Đang dùng: ${Config.city(this@ConfigActivity)}"; setPadding(0, px(6), 0, px(14)) })
        root.addView(TextView(this).apply { text = "Kiểu giao diện" })
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        Renderer.THEMES.forEachIndexed { i, t ->
            group.addView(RadioButton(this).apply { id = 1000 + i; text = t.name; isChecked = i == Config.style(this@ConfigActivity) })
        }
        group.setOnCheckedChangeListener { _, id ->
            Config.saveStyle(this, id - 1000)
            sendBroadcast(Intent(this, ClockWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE))
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        root.addView(group)
        root.addView(TextView(this).apply { text = "Thành phố"; setPadding(0, px(12), 0, 0) })
        val input = EditText(this).apply {
            hint = "Nhập tên thành phố, ví dụ: Đà Nẵng"; inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH; setSingleLine()
        }
        val btn = Button(this).apply { text = "Tìm" }
        val status = TextView(this).apply { setPadding(0, px(8), 0, px(8)) }
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        val list = ListView(this).apply { this.adapter = adapter }
        root.addView(input); root.addView(btn); root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            text = "Xong"
            setOnClickListener {
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)); finish()
            }
        })
        setContentView(root)

        fun search() {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return
            status.text = "Đang tìm…"
            thread {
                val found = mutableListOf<Place>(); var err: String? = null
                try {
                    val u = "https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(q, "UTF-8")}&count=8&language=vi"
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 6000; c.readTimeout = 6000
                    val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("results")
                    for (i in 0 until (arr?.length() ?: 0)) {
                        val o = arr!!.getJSONObject(i)
                        val name = o.getString("name")
                        val label = listOf(name, o.optString("admin1"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", ")
                        found.add(Place(name, label, o.getDouble("latitude"), o.getDouble("longitude")))
                    }
                } catch (e: Exception) { err = "Không kết nối được. Kiểm tra mạng rồi thử lại." }
                runOnUiThread {
                    places.clear(); places.addAll(found)
                    adapter.clear(); adapter.addAll(found.map { it.label })
                    status.text = err ?: if (found.isEmpty()) "Không tìm thấy. Thử tên khác hoặc viết không dấu." else "Chạm vào kết quả để chọn:"
                }
            }
        }
        btn.setOnClickListener { search() }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false }
        list.setOnItemClickListener { _, _, i, _ ->
            val p = places[i]
            Config.save(this, p.name, p.lat, p.lon)
            sendBroadcast(Intent(this, ClockWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE))
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            finish()
        }
    }
}
