package com.example.flipwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.PowerManager
import android.widget.RemoteViews
import java.util.Calendar
import kotlin.concurrent.thread

class ClockWidget : AppWidgetProvider() {
    private val tickAction = "com.example.flipwidget.TICK"
    private val replayAction = "com.example.flipwidget.REPLAY"
    private val refreshOn = setOf(tickAction, replayAction, AppWidgetManager.ACTION_APPWIDGET_UPDATE, Intent.ACTION_TIME_CHANGED,
        Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_BOOT_COMPLETED)

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action in refreshOn) {
            val pending = goAsync()
            val replay = intent.action == replayAction
            thread {
                try { refresh(ctx, replay) } finally { pending.finish() }
            }
        }
    }
    override fun onDisabled(ctx: Context) { alarm(ctx).cancel(tickIntent(ctx)) }

    private fun views(ctx: Context, bmp: Bitmap) = RemoteViews(ctx.packageName, R.layout.widget).apply {
        setImageViewBitmap(R.id.img, bmp)
        setOnClickPendingIntent(R.id.img, PendingIntent.getBroadcast(ctx, 1,
            Intent(ctx, ClockWidget::class.java).setAction(replayAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
    }

    private fun refresh(ctx: Context, replay: Boolean) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
        if (ids.isEmpty()) return
        scheduleNext(ctx)

        val prefs = ctx.getSharedPreferences("shown", 0)
        val (hs, ms) = Renderer.timeStrings(ctx)
        val lastH = prefs.getString("h", null); val lastM = prefs.getString("m", null)
        var old: Pair<String, String>? = null
        if (replay) old = Renderer.timeStrings(ctx, Calendar.getInstance().apply { add(Calendar.MINUTE, -1) })
        else if (lastH != null && lastM != null && (lastH != hs || lastM != ms)) old = lastH to lastM

        val cached = Weather.cached(ctx)
        val screenOn = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        if (old != null && (screenOn || replay)) {   // chỉ lật khi đang bật màn hình, đỡ tốn pin
            val n = 10
            for (k in 1 until n) {
                mgr.updateAppWidget(ids, views(ctx, Renderer.render(ctx, cached, Anim(old.first, old.second, k / n.toFloat()))))
                Thread.sleep(35)
            }
        }
        mgr.updateAppWidget(ids, views(ctx, Renderer.render(ctx, cached)))
        prefs.edit().putString("h", hs).putString("m", ms).apply()

        val fresh = Weather.refreshIfStale(ctx)
        if (fresh != null && fresh.ts != cached?.ts) mgr.updateAppWidget(ids, views(ctx, Renderer.render(ctx, fresh)))
    }

    private fun scheduleNext(ctx: Context) {
        val next = (System.currentTimeMillis() / 60000 + 1) * 60000
        val am = alarm(ctx); val pi = tickIntent(ctx)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi) }
    }
    private fun alarm(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun tickIntent(ctx: Context) = PendingIntent.getBroadcast(ctx, 0,
        Intent(ctx, ClockWidget::class.java).setAction(tickAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}
