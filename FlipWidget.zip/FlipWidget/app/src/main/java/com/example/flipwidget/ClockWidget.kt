package com.example.flipwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.concurrent.thread

class ClockWidget : AppWidgetProvider() {
    private val tickAction = "com.example.flipwidget.TICK"
    private val refreshOn = setOf(tickAction, AppWidgetManager.ACTION_APPWIDGET_UPDATE, Intent.ACTION_TIME_CHANGED,
        Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_BOOT_COMPLETED)

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action in refreshOn) {
            val pending = goAsync()
            thread {
                try { refresh(ctx) } finally { pending.finish() }
            }
        }
    }
    override fun onDisabled(ctx: Context) { alarm(ctx).cancel(tickIntent(ctx)) }

    private fun refresh(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
        if (ids.isEmpty()) return
        val draw = { w: Weather? ->
            val views = RemoteViews(ctx.packageName, R.layout.widget).apply { setImageViewBitmap(R.id.img, Renderer.render(ctx, w)) }
            mgr.updateAppWidget(ids, views)
        }
        draw(Weather.cached(ctx))
        val fresh = Weather.refreshIfStale(ctx)
        if (fresh != null && fresh.ts != Weather.cached(ctx)?.ts) draw(fresh)
        val next = (System.currentTimeMillis() / 60000 + 1) * 60000
        alarm(ctx).setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(ctx))
    }
    private fun alarm(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private fun tickIntent(ctx: Context) = PendingIntent.getBroadcast(ctx, 0,
        Intent(ctx, ClockWidget::class.java).setAction(tickAction), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}
