package com.example.flipwidget

import android.content.Context
import android.graphics.*
import android.text.format.DateFormat
import java.util.Calendar
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos

/** Bộ màu cho từng kiểu giao diện. Màu dạng 0xAARRGGBB. */
class Theme(
    val name: String,
    val topA: Long, val topB: Long, val botA: Long, val botB: Long, val digit: Long,
    val rim: Long, val rimW: Float,
    val solid: Boolean, val grain: Boolean, val liquid: Boolean,
    val panelA: Long, val panelB: Long, val panelRim: Long,
    val text: Long, val dim: Long, val accent: Long,
    val hinge: Long, val pivot: Long, val ampm: Long, val moonDark: Long, val tshadow: Boolean
)

/** Vẽ toàn bộ widget thành một ảnh bitmap. */
object Renderer {
    val THEMES = listOf(
        Theme("Cổ điển", 0xFFFDFDFF, 0xFFEBEBF1, 0xFFDCDCE5, 0xFFF6F6FA, 0xFF1A1826, 0, 0f, true, false, false,
            0xCC2A2545, 0xCC141228, 0x26FFFFFF, 0xFFF5F3FC, 0xFFB4AFCC, 0xFFA99BFF, 0x4D141228, 0xFF77758A, 0xFF6A6880, 0xFF0B0916, false),
        Theme("Tối", 0xFF2C2942, 0xFF222036, 0xFF1B1930, 0xFF25223A, 0xFFF2F0FA, 0x1AFFFFFF, 2f, true, false, false,
            0xE61C1A2E, 0xE6141228, 0x1FFFFFFF, 0xFFF5F3FC, 0xFFA6A1C2, 0xFFA99BFF, 0x80000000, 0xFF14122A, 0xFF8C88A8, 0xFF0B0916, false),
        Theme("Trong suốt", 0x0DFFFFFF, 0x0DFFFFFF, 0x0DFFFFFF, 0x0DFFFFFF, 0xFFFFFFFF, 0x99FFFFFF, 2.5f, false, false, false,
            0x00000000, 0x00000000, 0x66FFFFFF, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x66FFFFFF, 0x99FFFFFF, 0xCCFFFFFF, 0x990B0916, true),
        Theme("Kính mờ", 0x73FFFFFF, 0x5CFFFFFF, 0x4DFFFFFF, 0x38FFFFFF, 0xFFFFFFFF, 0x66FFFFFF, 2f, false, true, false,
            0x47FFFFFF, 0x2EFFFFFF, 0x59FFFFFF, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x59FFFFFF, 0x99FFFFFF, 0xE6FFFFFF, 0xFF0B0916, true),
        Theme("Kính lỏng", 0x45FFFFFF, 0x24FFFFFF, 0x1CFFFFFF, 0x2EFFFFFF, 0xFFFFFFFF, 0, 0f, false, false, true,
            0x33FFFFFF, 0x12FFFFFF, 0, 0xFFFFFFFF, 0xE6FFFFFF, 0xFFFFFFFF, 0x59FFFFFF, 0x80FFFFFF, 0xE6FFFFFF, 0xE60B0916, true)
    )

    private val Long.i get() = this.toInt()
    private const val W = 800
    private const val H = 512
    private const val PAD = 10f
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val reg = Typeface.create("sans-serif", Typeface.NORMAL)
    private val med = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val THU = listOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")

    private fun paint(t: Theme, size: Float, color: Long, tf: Typeface = reg, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color.i; typeface = tf; textAlign = align
            if (t.tshadow) setShadowLayer(8f, 0f, 2f, 0x66000000)
        }

    fun render(ctx: Context, w: Weather?): Bitmap {
        val t = THEMES[Config.style(ctx).coerceIn(0, THEMES.lastIndex)]
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val now = Calendar.getInstance()
        val h24 = now.get(Calendar.HOUR_OF_DAY)
        val is24 = DateFormat.is24HourFormat(ctx)
        val hh = if (is24) h24 else (h24 % 12).let { if (it == 0) 12 else it }
        val cardW = (W - 2 * PAD - 16) / 2; val cardH = 260f
        card(c, t, PAD, PAD, cardW, cardH, "%02d".format(hh), if (is24) null else if (h24 >= 12) "PM" else "AM")
        card(c, t, PAD + cardW + 16, PAD, cardW, cardH, "%02d".format(now.get(Calendar.MINUTE)), null)

        val top = PAD + cardH + 24; val bottom = H - PAD
        val panel = RectF(PAD, top, W - PAD, bottom)
        val pr = if (t.liquid) 44f else 34f
        if (t.panelA != 0L || t.panelB != 0L)
            c.drawRoundRect(panel, pr, pr, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, top, 0f, bottom, t.panelA.i, t.panelB.i, Shader.TileMode.CLAMP) })
        if (t.liquid) gloss(c, panel, pr)
        rim(c, panel, pr, t.panelRim, t.liquid, 2f)

        val lunar = Lunar.convert(now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1, now.get(Calendar.YEAR))
        val lx = PAD + 40
        c.drawText("%s, %02d/%02d".format(THU[now.get(Calendar.DAY_OF_WEEK) - 1], now.get(Calendar.DAY_OF_MONTH), now.get(Calendar.MONTH) + 1),
            lx, top + 76, paint(t, 34f, t.text, med))
        c.drawText("Âm lịch ${lunar.d}/${lunar.m}${if (lunar.leap) " nhuận" else ""}", lx, top + 120, paint(t, 28f, t.dim))
        c.drawText("Năm ${Lunar.yearName(lunar.y)}", lx, top + 156, paint(t, 28f, t.accent))

        val rx = W - PAD - 40
        c.drawText(Config.city(ctx), rx, top + 52, paint(t, 26f, t.dim, reg, Paint.Align.RIGHT))
        if (w != null) {
            c.drawText("${w.temp}°", rx, top + 126, paint(t, 78f, t.text, light, Paint.Align.RIGHT))
            c.drawText("${w.icon} ${w.text}", rx, top + 164, paint(t, 28f, t.dim, reg, Paint.Align.RIGHT))
            c.drawText("${w.hi}° / ${w.lo}°", rx, top + 196, paint(t, 26f, t.dim, reg, Paint.Align.RIGHT))
        } else c.drawText("Đang tải…", rx, top + 126, paint(t, 30f, t.dim, reg, Paint.Align.RIGHT))

        moon(c, t, W / 2f, top - 4, 64f, lunar.d)
        return bmp
    }

    /** Viền kính: kính lỏng dùng viền chuyển sáng-tối chéo như ánh sáng bắt vào mép kính. */
    private fun rim(c: Canvas, rc: RectF, r: Float, col: Long, liquid: Boolean, wd: Float) {
        val sw = if (liquid) 3f else wd
        if (sw <= 0f || (!liquid && col == 0L)) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = sw
            if (liquid) shader = LinearGradient(rc.left, rc.top, rc.right, rc.bottom,
                intArrayOf(0xE6FFFFFF.toInt(), 0x26FFFFFF, 0x26FFFFFF, 0xBFFFFFFF.toInt()), floatArrayOf(0f, .35f, .65f, 1f), Shader.TileMode.CLAMP)
            else color = col.i
        }
        val h = sw / 2
        c.drawRoundRect(RectF(rc.left + h, rc.top + h, rc.right - h, rc.bottom - h), r, r, p)
    }

    /** Ánh bóng phía trên, ánh sáng đáy và sắc xanh-tím nhẹ của kính lỏng. */
    private fun gloss(c: Canvas, rc: RectF, r: Float) {
        c.save(); c.clipPath(Path().apply { addRoundRect(rc, r, r, Path.Direction.CW) })
        val tm = rc.top + rc.height() * .5f; val bt = rc.bottom - rc.height() * .18f
        c.drawRect(rc, Paint().apply { shader = LinearGradient(rc.left, rc.top, rc.right, rc.bottom, 0x1F5AA9FF, 0x1FB07CFF, Shader.TileMode.CLAMP) })
        c.drawRect(rc.left, rc.top, rc.right, tm, Paint().apply { shader = LinearGradient(0f, rc.top, 0f, tm, 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP) })
        c.drawRect(rc.left, bt, rc.right, rc.bottom, Paint().apply { shader = LinearGradient(0f, bt, 0f, rc.bottom, 0x00FFFFFF, 0x2EFFFFFF, Shader.TileMode.CLAMP) })
        c.restore()
    }

    private fun card(c: Canvas, t: Theme, x: Float, y: Float, w: Float, h: Float, digits: String, ampm: String?) {
        val r = if (t.liquid) 36f else 24f; val mid = y + h / 2
        val full = RectF(x, y, x + w, y + h)
        if (t.solid) {
            c.drawRoundRect(RectF(x + 16, y + 12, x + w - 16, y + h + 14), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.pivot.i })
            c.drawRoundRect(full, r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.botB.i; setShadowLayer(18f, 0f, 8f, 0x66000000) })
        }
        fun half(top: Boolean, c0: Long, c1: Long) {
            val p = Path(); val rr = if (top) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            val a = if (top) y else mid; val b = if (top) mid else y + h
            p.addRoundRect(RectF(x, a, x + w, b), rr, Path.Direction.CW)
            c.drawPath(p, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, a, 0f, b, c0.i, c1.i, Shader.TileMode.CLAMP) })
        }
        half(true, t.topA, t.topB); half(false, t.botA, t.botB)
        if (t.grain) { // hạt mịn cho kính mờ
            val rnd = Random(7); val pts = FloatArray(900)
            for (i in 0 until 450) { pts[i * 2] = x + rnd.nextFloat() * w; pts[i * 2 + 1] = y + rnd.nextFloat() * h }
            c.save(); c.clipPath(Path().apply { addRoundRect(full, r, r, Path.Direction.CW) })
            c.drawPoints(pts, Paint().apply { color = 0x1AFFFFFF; strokeWidth = 2.2f; strokeCap = Paint.Cap.ROUND })
            c.restore()
        }
        if (t.liquid) gloss(c, full, r)
        val tp = paint(t, 330f, t.digit, light, Paint.Align.CENTER).apply { letterSpacing = -0.03f }
        val b = Rect(); tp.getTextBounds(digits, 0, digits.length, b)
        c.save(); c.clipPath(Path().apply { addRoundRect(full, r, r, Path.Direction.CW) })
        c.drawText(digits, x + w / 2, mid - b.exactCenterY(), tp); c.restore()
        c.drawRect(x + (if (t.liquid) 18f else 0f), mid - 2, x + w - (if (t.liquid) 18f else 0f), mid + 2, Paint().apply { color = t.hinge.i })
        val pv = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.pivot.i }
        c.drawRoundRect(RectF(x - 4, mid - 14, x + 10, mid + 14), 6f, 6f, pv)
        c.drawRoundRect(RectF(x + w - 10, mid - 14, x + w + 4, mid + 14), 6f, 6f, pv)
        rim(c, full, r, t.rim, t.liquid, t.rimW)
        if (ampm != null) c.drawText(ampm, x + 26, y + h - 24, paint(t, 28f, t.ampm, med).apply { letterSpacing = 0.05f })
    }

    private fun moon(c: Canvas, t: Theme, cx: Float, cy: Float, r: Float, lunarDay: Int) {
        c.save(); c.translate(cx, cy)
        c.drawCircle(0f, 0f, r + 1, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.moonDark.i; setShadowLayer(14f, 0f, 6f, 0x99000000.toInt()) })
        val p = ((lunarDay - 1) % 29.53) / 29.53
        val wax = p <= 0.5; val pp = if (wax) p else 1 - p
        val k = maxOf(abs(cos(2 * Math.PI * pp)).toFloat() * r, 0.5f)
        if (!wax) c.scale(-1f, 1f)
        val path = Path().apply {
            moveTo(0f, -r); arcTo(RectF(-r, -r, r, r), -90f, 180f)
            arcTo(RectF(-k, -r, k, r), 90f, if (pp < 0.25) -180f else 180f); close()
        }
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(-r * 0.2f, -r * 0.3f, r * 1.4f, intArrayOf(0xFFECEBF1.toInt(), 0xFFAAA8B5.toInt(), 0xFF6E6C7B.toInt()),
                floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP) })
        c.restore()
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x40FFFFFF })
    }
}
