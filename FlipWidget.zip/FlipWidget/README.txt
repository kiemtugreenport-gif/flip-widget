FLIP WIDGET - widget đồng hồ lật trang cho Android

1. Cài Android Studio (bản mới nhất), chọn File > Open và mở thư mục FlipWidget.
2. Chờ Gradle đồng bộ xong.
3. Thành phố chọn trong cài đặt widget (không cần sửa mã).
4. Bật "Gỡ lỗi USB" trên điện thoại, cắm cáp, bấm nút Run (tam giác xanh).
   (Hoặc Build > Build APK(s) rồi chép file app-debug.apk sang điện thoại để cài.)
5. Trên điện thoại: nhấn giữ màn hình chính > Widget > Flip Widget > kéo ra màn hình.
6. Nếu số phút không nhảy đều: Cài đặt > Ứng dụng > Flip Widget > Pin > chọn "Không hạn chế".
